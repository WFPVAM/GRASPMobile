package org.javarosa.formmanager.api.transitions;

public interface FormListTransitions {
	public void cancel();
	public void formSelected(String formURI);
}
