/**
 * 
 */
package org.javarosa.formmanager.view;

/**
 * @author ctsims
 *
 */
public interface InvalidInputListener {
	public void invalidNativeInput(String input);
}
