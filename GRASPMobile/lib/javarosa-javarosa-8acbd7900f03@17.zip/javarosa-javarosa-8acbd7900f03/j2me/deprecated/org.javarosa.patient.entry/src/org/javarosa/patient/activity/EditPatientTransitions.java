package org.javarosa.patient.activity;

public interface EditPatientTransitions {
	void cancel ();
	void done ();
}
