/**
 * 
 */
package org.javarosa.j2me.view;

/**
 * @author ctsims
 *
 */
public interface ProgressIndicator {

	public double getProgress();
}
