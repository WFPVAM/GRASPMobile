/**
 * 
 */
package org.javarosa.services.transport;

/**
 * @author ctsims
 *
 */
public class UnrecognizedResponseException extends Exception {
	public UnrecognizedResponseException(String message) {
		super(message);
	}
}
