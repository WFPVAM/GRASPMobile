package org.javarosa.services.transport;

public interface TransportResult {
	

	public byte[] getPayload();
	public boolean isSuccess();


}
